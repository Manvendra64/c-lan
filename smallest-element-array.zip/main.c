/******************************************************************************

wap to find the smallest element in an array

*******************************************************************************/
#include <stdio.h>

int main()
{
   int i,smallest,udef;
 printf("enter the size of array");
 scanf("%d",&udef);
 int arr[udef];
 printf("enter %d elements of an array",udef);
 for(i=0;i<=udef-1;i++)
 {
     scanf("%d",&arr[i]);
 }
 smallest=arr[0];
 for(i=0;i<=udef-1;i++)
 {
     if(smallest>arr[i])
     {
         smallest=arr[i];
     }
 }
 printf("smallest element of an array is %d",smallest);
 return 0;
}

